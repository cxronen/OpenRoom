	</div>
	
	<div id="clear_both"></div>
	<br/>
	Developed by Ball State University Libraries<br/>
	Copyright (C) 2012 Ball State University Libraries
</div>
<div id="themeswitch" onClick="javascript:document.cookie='theme=mobile';location.reload(true);">Switch to Mobile View</div>
<br/><br/><br/>
<br/><br/><br/>
<br/><br/><br/>
</body>
</html>
