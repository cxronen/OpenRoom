</div>
<div id="themeswitch" onClick="javascript:document.cookie='theme=desktop';location.reload(true);">Switch to Desktop View</div>
<div id="footnote">Works with Apple iPod, iPhone, iPad, Google Android devices, and Windows Phones<br/>Developed by Ball State University Libraries<br/>Copyright (C) 2012 Ball State University Libraries</div>
</body>
</html>
