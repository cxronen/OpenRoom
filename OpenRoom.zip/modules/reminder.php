<?php
	if($settings["remindermessage"] != ""){
		echo "<div id=\"remindermessage\"><span class=\"remindermessage\">". $settings["remindermessage"] ."</span></div>";
	}
?>
